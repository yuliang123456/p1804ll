from distutils.core import setup
setup(name='工厂模式',version='1.0',description='yl module',author='yl',   py_modules=['工厂模式'])

