# PythonSnake
A simple snake game I'm working on as a side project

This project is based on [this YouTube tutorial](https://www.youtube.com/watch?v=K5F-aGDIYaM&list=PL6gx4Cwl9DGAjkwJocj7vlc_mFU-4wXJq).
I wanted to get some experience using pygame, since that's what my group is planning on using for our computer science summative. 
I originally followed along with the lesson, but then decided to take a different turn, change some functions around, and add some features.

__Features__
+ WASD and arrow key controls
+ High score counter
+ Golden apples (worth 3 points)
+ Gradual speed increase 

(Please excuse the terrible graphics that I drew very basically in MS Paint. I'm not much of an artist.)
