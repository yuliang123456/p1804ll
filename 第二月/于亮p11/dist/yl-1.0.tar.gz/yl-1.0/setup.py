from distutils.core import setup
setup(name='yl',version='1.0',description='yl module',author='yl',py_modules=['suba.aa','suba.bb','subb.cc','subb.dd'])
